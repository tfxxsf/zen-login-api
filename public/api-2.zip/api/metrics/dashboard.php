<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente GET para este endpoint
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'msg'    => 'Método não permitido. Use GET.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();

[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}
// Buscar id do usuário
try {
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $userRow = $stmtUser->fetch();

    if (!$userRow) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao buscar usuário.'
    ]);
    exit;
}

$userId = (int)$userRow['id'];

// Período: últimos 10 dias
$labels = [];
$dateMap = [];

for ($i = 9; $i >= 0; $i--) {
    $d = new DateTime('-' . $i . ' days');
    $label = $d->format('Y-m-d');
    $labels[] = $label;
    $dateMap[$label] = [
        'cashin'  => 0.0,
        'cashout' => 0.0,
    ];
}

// Somar entradas (transaction_type = 1) e saídas (transaction_type = 2) por dia
try {
    $startDate = $labels[0] . ' 00:00:00';
    $endDate   = end($labels) . ' 23:59:59';

    $sql = 'SELECT DATE(created_at) AS d, transaction_type, COALESCE(SUM(amount),0) AS total
            FROM transactions
            WHERE user_id = :user_id
              AND status = 1
              AND created_at BETWEEN :startDate AND :endDate
            GROUP BY DATE(created_at), transaction_type';

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':user_id'   => $userId,
        ':startDate' => $startDate,
        ':endDate'   => $endDate,
    ]);

    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $dLabel = $r['d'];
        if (!isset($dateMap[$dLabel])) {
            continue;
        }

        $type = (int)$r['transaction_type'];
        $val  = (float)$r['total'];

        if ($type === 1) {
            $dateMap[$dLabel]['cashin'] += $val;
        } elseif ($type === 2) {
            $dateMap[$dLabel]['cashout'] += $val;
        }
    }
} catch (PDOException $e) {
    // se falhar, mantém tudo zero
}

// Conversão PIX: porcentagem de transações aprovadas no período
$conversionPix = 0.0;

try {
    // total de transações no período
    $sqlTotal = 'SELECT COUNT(*) AS total
                 FROM transactions
                 WHERE user_id = :user_id
                   AND created_at BETWEEN :startDate AND :endDate';

    $stmtTotal = $pdo->prepare($sqlTotal);
    $stmtTotal->execute([
        ':user_id'   => $userId,
        ':startDate' => $startDate,
        ':endDate'   => $endDate,
    ]);
    $totalRow = $stmtTotal->fetch(PDO::FETCH_ASSOC);
    $total    = $totalRow && isset($totalRow['total']) ? (int)$totalRow['total'] : 0;

    // total de aprovadas no período (status = 1)
    $sqlApproved = 'SELECT COUNT(*) AS total
                    FROM transactions
                    WHERE user_id = :user_id
                      AND status = 1
                      AND created_at BETWEEN :startDate AND :endDate';

    $stmtApproved = $pdo->prepare($sqlApproved);
    $stmtApproved->execute([
        ':user_id'   => $userId,
        ':startDate' => $startDate,
        ':endDate'   => $endDate,
    ]);
    $approvedRow = $stmtApproved->fetch(PDO::FETCH_ASSOC);
    $approved    = $approvedRow && isset($approvedRow['total']) ? (int)$approvedRow['total'] : 0;

    if ($total > 0) {
        $conversionPix = ($approved / $total) * 100.0;
        // Arredonda para 2 casas decimais
        $conversionPix = round($conversionPix, 2);
    }
} catch (PDOException $e) {
    // mantém 0 em caso de erro
}

$entradas = [];
$saidas   = [];

foreach ($labels as $label) {
    $entradas[] = $dateMap[$label]['cashin'];
    $saidas[]   = $dateMap[$label]['cashout'];
}

$response = [
    'revenue' => [
        'labels' => $labels,
        'values' => [
            [
                'label'  => 'Entradas',
                'values' => $entradas,
            ],
            [
                'label'  => 'Saídas',
                'values' => $saidas,
            ],
        ],
    ],
    'conversion' => [
        'all'    => $conversionPix,
        'pix'    => $conversionPix,
        'credit' => 0,
        'ticket' => 0,
        'refund' => 0,
    ],
];

http_response_code(200);
echo json_encode($response);