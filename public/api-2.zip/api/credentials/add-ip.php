<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'status'  => 405,
        'msg'     => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'status'  => 401,
        'msg'     => 'Token inválido ou expirado.'
    ]);
    exit;
}

$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body) || !isset($body['ip']) || !isset($body['pin'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'status'  => 400,
        'msg'     => 'JSON inválido. Informe ip e pin.'
    ]);
    exit;
}

$ip  = (string)$body['ip'];
$pin = (string)$body['pin'];

// Validação simples de IP (IPv4 ou IPv6)
if (!filter_var($ip, FILTER_VALIDATE_IP)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'status'  => 400,
        'msg'     => 'IP inválido.'
    ]);
    exit;
}

// Validar PIN: 6 dígitos
if (!preg_match('/^[0-9]{6}$/', $pin)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'status'  => 400,
        'msg'     => 'Credenciais incorretas.'
    ]);
    exit;
}

try {
    // Buscar usuário
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'status'  => 400,
            'msg'     => 'Credenciais incorretas.'
        ]);
        exit;
    }

    $userId = (int)$user['id'];

    // Validar PIN vinculado à conta
    $stmtPin = $pdo->prepare('SELECT pin_code FROM pin_accounts WHERE user_id = :user_id LIMIT 1');
    $stmtPin->execute([':user_id' => $userId]);
    $pinRow = $stmtPin->fetch(PDO::FETCH_ASSOC);

    if (!$pinRow || $pinRow['pin_code'] !== $pin) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'status'  => 400,
            'msg'     => 'Credenciais incorretas.'
        ]);
        exit;
    }

    // Verificar se o IP já existe para esta conta (não pode repetir na mesma conta)
    $stmtCheck = $pdo->prepare('SELECT 1 FROM allowed_ips WHERE user_id = :user_id AND ip = :ip LIMIT 1');
    $stmtCheck->execute([
        ':user_id' => $userId,
        ':ip'      => $ip,
    ]);

    if ($stmtCheck->fetchColumn()) {
        // IP já cadastrado para este usuário -> não permitir repetir
        http_response_code(200);
        echo json_encode(['success' => true]);
        exit;
    }

    // Inserir novo IP para este usuário (outros usuários podem ter o mesmo IP)
    $stmtIns = $pdo->prepare('INSERT INTO allowed_ips (user_id, ip) VALUES (:user_id, :ip)');
    $stmtIns->execute([
        ':user_id' => $userId,
        ':ip'      => $ip,
    ]);

    http_response_code(200);
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'status'  => 500,
        'msg'     => 'Erro ao adicionar IP.'
    ]);
}
