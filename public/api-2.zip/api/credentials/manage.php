<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'status'  => 405,
        'msg'     => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'status'  => 401,
        'msg'     => 'Token inválido ou expirado.'
    ]);
    exit;
}

$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body)
    || !isset($body['name'])
    || !isset($body['website'])
    || !isset($body['description'])
    || !isset($body['pin'])
) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'status'  => 400,
        'msg'     => 'JSON inválido. Informe name, website, description e pin.'
    ]);
    exit;
}

$name        = (string)$body['name'];
$website     = (string)$body['website'];
$description = (string)$body['description'];
$pin         = (string)$body['pin'];

// Validar PIN: 6 dígitos
if (!preg_match('/^[0-9]{6}$/', $pin)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'status'  => 400,
        'msg'     => 'Credenciais incorretas.'
    ]);
    exit;
}

try {
    // Buscar usuário
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'status'  => 400,
            'msg'     => 'Credenciais incorretas.'
        ]);
        exit;
    }

    $userId = (int)$user['id'];

    // Validar PIN vinculado
    $stmtPin = $pdo->prepare('SELECT pin_code FROM pin_accounts WHERE user_id = :user_id LIMIT 1');
    $stmtPin->execute([':user_id' => $userId]);
    $pinRow = $stmtPin->fetch(PDO::FETCH_ASSOC);

    if (!$pinRow || $pinRow['pin_code'] !== $pin) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'status'  => 400,
            'msg'     => 'Credenciais incorretas.'
        ]);
        exit;
    }

    // Verificar se já existe credencial
    $stmtCred = $pdo->prepare('SELECT id, client_id, secret_id FROM credentials WHERE user_id = :user_id LIMIT 1');
    $stmtCred->execute([':user_id' => $userId]);
    $cred = $stmtCred->fetch(PDO::FETCH_ASSOC);

    if (!$cred) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'status'  => 400,
            'msg'     => 'Credenciais não encontradas para este usuário.'
        ]);
        exit;
    }

    // Gerar novo client_id no mesmo formato: username + '_' + 16 dígitos
    $randomNumeric = substr(strval(mt_rand(1000000000000000, 9999999999999999)), 0, 16);
    $clientId      = $usernameFromToken . '_' . $randomNumeric;

    // Gerar novo secret: 8 letras minúsculas + 8 números, misturados
    $letters = 'abcdefghijklmnopqrstuvwxyz';
    $digits  = '0123456789';

    $secretChars = [];

    for ($i = 0; $i < 16; $i++) {
        $secretChars[] = $letters[random_int(0, strlen($letters) - 1)];
    }

    for ($i = 0; $i < 16; $i++) {
        $secretChars[] = $digits[random_int(0, strlen($digits) - 1)];
    }

    shuffle($secretChars);

    $secret = implode('', $secretChars);

    // Atualizar credencial com novo client_id, secret e dados de nome/descrição
    $stmtUpdate = $pdo->prepare('UPDATE credentials
                                 SET client_id = :client_id,
                                     secret_id = :secret_id,
                                     name = :name,
                                     description = :description
                                 WHERE id = :id');
    $stmtUpdate->execute([
        ':client_id'   => $clientId,
        ':secret_id'   => $secret,
        ':name'        => $name,
        ':description' => $description,
        ':id'          => (int)$cred['id'],
    ]);

    http_response_code(200);
    echo json_encode([
        'success'     => true,
        'credentials' => [
            'client_id'     => $clientId,
            'client_secret' => $secret,
        ],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'status'  => 500,
        'msg'     => 'Erro ao gerenciar credenciais.'
    ]);
}
