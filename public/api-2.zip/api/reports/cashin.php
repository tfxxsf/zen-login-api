<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use GET.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

// Buscar id do usuário
try {
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $userRow = $stmtUser->fetch();

    if (!$userRow) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao buscar usuário.'
    ]);
    exit;
}

$userId = (int)$userRow['id'];

// Filtros de paginação e datas
$page     = isset($_GET['page']) ? max(0, (int)$_GET['page']) : 0;
$perPage  = isset($_GET['perPage']) ? max(1, (int)$_GET['perPage']) : 20;
$startRaw = $_GET['startDate'] ?? null;
$endRaw   = $_GET['endDate'] ?? null;

$startDate = $startRaw ? urldecode($startRaw) : null;
$endDate   = $endRaw ? urldecode($endRaw) : null;

$where  = 'WHERE user_id = :user_id AND status = 1 AND transaction_type = 1';
$params = [':user_id' => $userId];

if ($startDate) {
    $where              .= ' AND created_at >= :startDate';
    $params[':startDate'] = $startDate;
}

if ($endDate) {
    $where              .= ' AND created_at <= :endDate';
    $params[':endDate'] = $endDate;
}

// Total geral (sem filtros de data, mas só cashin pagos)
try {
    $stmtTotal = $pdo->prepare('SELECT COUNT(*) AS total FROM transactions WHERE user_id = :user_id AND status = 1 AND transaction_type = 1');
    $stmtTotal->execute([':user_id' => $userId]);
    $rowTotal = $stmtTotal->fetch();
    $recordsTotal = (int)($rowTotal['total'] ?? 0);
} catch (PDOException $e) {
    $recordsTotal = 0;
}

// Total filtrado
try {
    $stmtFiltered = $pdo->prepare("SELECT COUNT(*) AS total FROM transactions $where");
    $stmtFiltered->execute($params);
    $rowFiltered     = $stmtFiltered->fetch();
    $recordsFiltered = (int)($rowFiltered['total'] ?? 0);
} catch (PDOException $e) {
    $recordsFiltered = 0;
}

$offset = $page * $perPage;

// Buscar transações paginadas
try {
    $sql = "SELECT transaction_id, amount, fee, status, end_to_end_id, old_balance, new_balance,
                   transaction_type, payment_method, description, created_at, updated_at
            FROM transactions
            $where
            ORDER BY created_at DESC
            LIMIT :limit OFFSET :offset";

    $stmt = $pdo->prepare($sql);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

    $stmt->execute();
    $rows = $stmt->fetchAll();
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao buscar transações.'
    ]);
    exit;
}

$transactions = [];

foreach ($rows as $r) {
    $transactions[] = [
        'transaction_id'   => $r['transaction_id'],
        'amount'           => (string)$r['amount'],
        'fee'              => (float)$r['fee'],
        'status'           => (int)$r['status'],
        'end_to_end_id'    => $r['end_to_end_id'],
        'old_balance'      => $r['old_balance'] !== null ? (string)$r['old_balance'] : null,
        'new_balance'      => $r['new_balance'] !== null ? (string)$r['new_balance'] : null,
        'transaction_type' => (int)$r['transaction_type'],
        'payment_method'   => (int)$r['payment_method'],
        'description'      => $r['description'],
        'created_at'       => $r['created_at'],
        'updated_at'       => $r['updated_at'],
    ];
}

// Widgets (totais) – com base no filtro atual
try {
    $sqlWidgets = "SELECT
        COUNT(*) AS total_transacoes,
        COALESCE(SUM(amount), 0) AS total_processado,
        COALESCE(SUM(fee), 0) AS total_taxas
      FROM transactions
      $where";

    $stmtW = $pdo->prepare($sqlWidgets);
    $stmtW->execute($params);
    $w = $stmtW->fetch();
} catch (PDOException $e) {
    $w = [
        'total_transacoes' => 0,
        'total_processado' => 0,
        'total_taxas'      => 0,
    ];
}

$totalPages = $perPage > 0 ? (int)ceil($recordsFiltered / $perPage) : 0;

$data = [
    'recordsTotal'    => $recordsTotal,
    'recordsFiltered' => $recordsFiltered,
    'transactions'    => $transactions,
    'widgets'         => [
        [
            'name'       => 'Total de Transações',
            'amount'     => (string)$w['total_transacoes'],
            'isCurrency' => false,
        ],
        [
            'name'       => 'Total Processado',
            'amount'     => (string)$w['total_processado'],
            'isCurrency' => true,
        ],
        [
            'name'       => 'Total de Taxas',
            'amount'     => (string)$w['total_taxas'],
            'isCurrency' => true,
        ],
        [
            'name'       => 'Ticket Médio',
            'amount'     => $w['total_transacoes'] > 0
                ? (string)($w['total_processado'] / $w['total_transacoes'])
                : '0',
            'isCurrency' => true,
        ],
    ],
    'pagination'      => [
        'currentPage' => $page,
        'perPage'     => $perPage,
        'totalPages'  => $totalPages,
    ],
];

http_response_code(200);
echo json_encode([
    'status' => 200,
    'data'   => $data,
    'msg'    => 'Success',
]);
