<?php

echo '{
    "status": 200,
    "data": {
        "recordsTotal": 0,
        "recordsFiltered": 0,
        "transactions": [],
        "widgets": [
            {
                "name": "Quantidade de Infra\u00e7\u00f5es",
                "amount": "0",
                "isCurrency": false
            },
            {
                "name": "Valor Total",
                "amount": 0,
                "isCurrency": true
            },
            {
                "name": "Ticket M\u00e9dio",
                "amount": null,
                "isCurrency": true
            },
            {
                "name": "Prazo",
                "amount": "7 dias",
                "isCurrency": false
            }
        ],
        "pagination": {
            "currentPage": 1,
            "perPage": 20,
            "totalPages": 1
        }
    },
    "msg": "Success"
}';