<?php
date_default_timezone_set('America/Sao_Paulo');
// Configurações de conexão com o banco de dados
// Ajuste esses dados conforme o seu ambiente (host, usuário, senha e nome do banco)
$DB_HOST = '127.0.0.1';
$DB_NAME = 'snowpaybr';
$DB_USER = 'snowpaybr';
$DB_PASS = 'snowpaybr';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao conectar ao banco de dados.',
    ]);
    exit;
}
