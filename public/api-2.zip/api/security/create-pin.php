<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body) || !isset($body['new_pin'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'JSON inválido. Informe new_pin.'
    ]);
    exit;
}

$newPin = (string)$body['new_pin'];

// Validar: exatamente 6 dígitos numéricos
if (!preg_match('/^[0-9]{6}$/', $newPin)) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'PIN deve conter exatamente 6 números.'
    ]);
    exit;
}

try {
    // Buscar usuário para obter id
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }

    $userId = (int)$user['id'];
    $now    = (new DateTime())->format('Y-m-d H:i:s');

    // Apagar PIN anterior (se existir)
    $stmtDel = $pdo->prepare('DELETE FROM pin_accounts WHERE user_id = :user_id');
    $stmtDel->execute([':user_id' => $userId]);

    // Inserir novo PIN
    $stmtIns = $pdo->prepare('INSERT INTO pin_accounts (user_id, pin_code, created_at)
                              VALUES (:user_id, :pin_code, :created_at)');
    $stmtIns->execute([
        ':user_id'    => $userId,
        ':pin_code'   => $newPin,
        ':created_at' => $now,
    ]);

    http_response_code(200);
    echo json_encode([
        'status' => 200,
        'data'   => null,
        'msg'    => 'PIN cadastrado com sucesso.'
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao cadastrar PIN.'
    ]);
}
