<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use GET.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

try {
    // Buscar usuário para obter id
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }

    $userId = (int)$user['id'];

    // Verificar se existe PIN vinculado ao usuário
    $stmtPin = $pdo->prepare('SELECT 1 FROM pin_accounts WHERE user_id = :user_id LIMIT 1');
    $stmtPin->execute([':user_id' => $userId]);
    $hasPin = (bool)$stmtPin->fetchColumn();

    $response = [
        'two_factor_auth' => false,
        'pin_code'        => $hasPin,
        'email_verified'  => false,
        'phone_verified'  => false,
    ];

    http_response_code(200);
    echo json_encode($response);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao carregar dados de segurança.'
    ]);
}
