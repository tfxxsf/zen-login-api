<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body) || !isset($body['pin']) || !isset($body['new_pin'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'JSON inválido. Informe pin e new_pin.'
    ]);
    exit;
}

$currentPin = (string)$body['pin'];
$newPin     = (string)$body['new_pin'];

// Validar formato dos PINs: exatamente 6 dígitos
if (!preg_match('/^[0-9]{6}$/', $currentPin) || !preg_match('/^[0-9]{6}$/', $newPin)) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'PINs devem conter exatamente 6 números.'
    ]);
    exit;
}

try {
    // Buscar usuário
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }

    $userId = (int)$user['id'];

    // Verificar se PIN atual confere
    $stmtCheck = $pdo->prepare('SELECT pin_code FROM pin_accounts WHERE user_id = :user_id LIMIT 1');
    $stmtCheck->execute([':user_id' => $userId]);
    $row = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    if (!$row || $row['pin_code'] !== $currentPin) {
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => null,
            'msg'    => 'PIN atual inválido.'
        ]);
        exit;
    }

    $now = (new DateTime())->format('Y-m-d H:i:s');

    // Atualizar o PIN existente
    $stmtUpdate = $pdo->prepare('UPDATE pin_accounts SET pin_code = :new_pin, created_at = :created_at WHERE user_id = :user_id');
    $stmtUpdate->execute([
        ':new_pin'    => $newPin,
        ':created_at' => $now,
        ':user_id'    => $userId,
    ]);

    http_response_code(200);
    echo json_encode([
        'status' => 200,
        'data'   => null,
        'msg'    => 'PIN alterado com sucesso.'
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao alterar PIN.'
    ]);
}
