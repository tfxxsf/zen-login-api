<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body)
    || !isset($body['current_password'])
    || !isset($body['new_password'])
    || !isset($body['new_password_confirmation'])
    || !isset($body['pin'])
) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'JSON inválido. Informe current_password, new_password, new_password_confirmation e pin.'
    ]);
    exit;
}

$currentPassword = (string)$body['current_password'];
$newPassword     = (string)$body['new_password'];
$newPasswordConf = (string)$body['new_password_confirmation'];
$pin             = (string)$body['pin'];

// Verificar formato do PIN: 6 dígitos
if (!preg_match('/^[0-9]{6}$/', $pin)) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'Credenciais incorretas.'
    ]);
    exit;
}

// Verificar se nova senha e confirmação batem
if ($newPassword !== $newPasswordConf) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'Credenciais incorretas.'
    ]);
    exit;
}

try {
    // Buscar usuário e hash da senha atual
    $stmtUser = $pdo->prepare('SELECT id, password_hash FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => null,
            'msg'    => 'Credenciais incorretas.'
        ]);
        exit;
    }

    $userId       = (int)$user['id'];
    $passwordHash = $user['password_hash'];

    // Validar senha atual
    if (!password_verify($currentPassword, $passwordHash)) {
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => null,
            'msg'    => 'Credenciais incorretas.'
        ]);
        exit;
    }

    // Validar PIN vinculado
    $stmtPin = $pdo->prepare('SELECT pin_code FROM pin_accounts WHERE user_id = :user_id LIMIT 1');
    $stmtPin->execute([':user_id' => $userId]);
    $pinRow = $stmtPin->fetch(PDO::FETCH_ASSOC);

    if (!$pinRow || $pinRow['pin_code'] !== $pin) {
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => null,
            'msg'    => 'Credenciais incorretas.'
        ]);
        exit;
    }

    // Atualizar senha
    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);

    $stmtUpdate = $pdo->prepare('UPDATE users SET password_hash = :password_hash WHERE id = :id');
    $stmtUpdate->execute([
        ':password_hash' => $newHash,
        ':id'            => $userId,
    ]);

    http_response_code(200);
    echo json_encode([
        'status' => 200,
        'data'   => null,
        'msg'    => 'Senha alterada com sucesso.'
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao alterar senha.'
    ]);
}
