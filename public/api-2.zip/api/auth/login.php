<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

// Conexão com o banco de dados
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$input = file_get_contents('php://input');
$data  = json_decode($input, true);

if (!is_array($data) || !isset($data['username']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'JSON inválido. Envie {"username":"...","password":"..."}'
    ]);
    exit;
}

// Buscar usuário no banco de dados
$username = $data['username'];
$password = $data['password'];

try {
    $stmt = $pdo->prepare('SELECT id, username, password_hash FROM users WHERE username = :username LIMIT 1');
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao consultar usuário.'
    ]);
    exit;
}

// Verificar credenciais
if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'Credenciais inválidas. Verifique seu usuário e senha.'
    ]);
    exit;
}

// Gerar token com validade de 1 hora (contendo username e timestamp de validade)
$token = generate_login_token($username);

$response = [
    'status' => 200,
    'data'   => $token,
    'msg'    => 'Login realizado com sucesso'
];

http_response_code(200);
echo json_encode($response);
