<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body)
    || !isset($body['username'])
    || !isset($body['email'])
    || !isset($body['phone'])
    || !isset($body['document'])
    || !isset($body['revenue'])
    || !isset($body['password'])
    || !isset($body['password_confirmation'])
    || !isset($body['affiliate'])
    || !isset($body['agreement'])
    || !isset($body['segments'])
) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'JSON inválido. Verifique os campos enviados.'
    ]);
    exit;
}

$username   = trim((string)$body['username']);
$email      = trim((string)$body['email']);
$phone      = trim((string)$body['phone']);
$document   = trim((string)$body['document']);
$revenue    = (string)$body['revenue'];
$password   = (string)$body['password'];
$passConf   = (string)$body['password_confirmation'];
$affiliate  = (string)$body['affiliate'];
$agreement  = (bool)$body['agreement'];
$name       = isset($body['name']) ? trim((string)$body['name']) : $username;
$segments   = trim((string)$body['segments']);

// Validar senha e confirmação
if ($password === '' || $password !== $passConf) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'Senha inválida ou não confere com a confirmação.'
    ]);
    exit;
}

// Opcional: exigir aceite de termos se for obrigatório
// if (!$agreement) { ... }

try {
    // Verificar se username ou email já existem
    $stmtCheck = $pdo->prepare('SELECT id FROM users WHERE username = :username OR email = :email LIMIT 1');
    $stmtCheck->execute([
        ':username' => $username,
        ':email'    => $email,
    ]);

    if ($stmtCheck->fetch(PDO::FETCH_ASSOC)) {
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => null,
            'msg'    => 'Usuário ou e-mail já cadastrados.'
        ]);
        exit;
    }

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $now          = (new DateTime())->format('Y-m-d H:i:s');

    // Buscar defaults da tabela settings (primeiro registro), mas sem quebrar se a tabela não existir
    $settings = null;

    try {
        $stmtSettings = $pdo->query('SELECT
                default_meta,
                default_cashin_fee,
                default_cashout_fee,
                default_cripto_fee,
                default_min_fee,
                default_manager_name,
                default_manager_phone
            FROM settings
            ORDER BY id ASC
            LIMIT 1');

        if ($stmtSettings !== false) {
            $rowSettings = $stmtSettings->fetch(PDO::FETCH_ASSOC);
            if ($rowSettings !== false) {
                $settings = $rowSettings;
            }
        }
    } catch (Throwable $e) {
        // Se der erro (por exemplo, tabela não existe), segue com defaults 0/null
        $settings = null;
    }

    $defaultMeta          = $settings && isset($settings['default_meta']) ? (int)$settings['default_meta'] : 0;
    $defaultCashinFee     = $settings && isset($settings['default_cashin_fee']) ? (float)$settings['default_cashin_fee'] : 0.0;
    $defaultCashoutFee    = $settings && isset($settings['default_cashout_fee']) ? (float)$settings['default_cashout_fee'] : 0.0;
    $defaultCriptoFee     = $settings && isset($settings['default_cripto_fee']) ? (float)$settings['default_cripto_fee'] : 0.0;
    $defaultMinFee        = $settings && isset($settings['default_min_fee']) ? (float)$settings['default_min_fee'] : 0.0;
    $defaultManagerName   = $settings && isset($settings['default_manager_name']) ? $settings['default_manager_name'] : null;
    $defaultManagerPhone  = $settings && isset($settings['default_manager_phone']) ? $settings['default_manager_phone'] : null;

    // Inserir usuário com documentos como not_sent, usando defaults de settings
    $stmtInsert = $pdo->prepare('INSERT INTO users (
            username, password_hash,
            balance_available, balance_blocked, balance_retained,
            revenue_total, revenue_monthly_revenue, revenue_ranking, revenue_next_meta,
            rate_cashin_fee, rate_cashin_type,
            rate_cashout_fee, rate_cashout_type,
            rate_cashout_api_fee, rate_cashout_api_type,
            rate_cripto_fee, rate_min_fee,
            name, email, phone, profile, document, document_status, status,
            manager_name, manager_phone, created_at,
            document_front_status, document_back_status, selfie_status, contract_status
        ) VALUES (
            :username, :password_hash,
            0.000000, 0.000000, 0.000000,
            0.00, 0.00, :revenue_ranking, :revenue_next_meta,
            :rate_cashin_fee, 0,
            :rate_cashout_fee, 0,
            :rate_cashout_api_fee, 0,
            :rate_cripto_fee, :rate_min_fee,
            :name, :email, :phone, :profile, :document, :document_status, :status,
            :manager_name, :manager_phone, :created_at,
            :document_front_status, :document_back_status, :selfie_status, :contract_status
        )');

    $stmtInsert->execute([
        ':username'              => $username,
        ':password_hash'         => $passwordHash,
        ':revenue_ranking'       => $revenue,
        ':revenue_next_meta'     => $defaultMeta,
        ':rate_cashin_fee'       => $defaultCashinFee,
        ':rate_cashout_fee'      => $defaultCashoutFee,
        // Campos *_api_* usam o mesmo valor de cashout_fee
        ':rate_cashout_api_fee'  => $defaultCashoutFee,
        ':rate_cripto_fee'       => $defaultCriptoFee,
        ':rate_min_fee'          => $defaultMinFee,
        ':name'                  => $name,
        ':email'                 => $email,
        ':phone'                 => $phone,
        ':profile'               => null,
        ':document'              => $document,
        ':document_status'       => 'not_sent',
        ':status'                => 1,
        // Se houver defaults de manager na settings, eles prevalecem; senão usa affiliate/NULL
        ':manager_name'          => $defaultManagerName !== null ? $defaultManagerName : $affiliate,
        ':manager_phone'         => $defaultManagerPhone !== null ? $defaultManagerPhone : null,
        ':created_at'            => $now,
        ':document_front_status' => 'not_sent',
        ':document_back_status'  => 'not_sent',
        ':selfie_status'         => 'not_sent',
        ':contract_status'       => 'not_sent',
    ]);

    // Criar registro na tabela documents para esse usuário
    $newUserId = (int)$pdo->lastInsertId();
    $nowDoc    = $now;

    $stmtDoc = $pdo->prepare('INSERT INTO documents (
            user_id,
            document_front_status, document_back_status, selfie_status, contract_status, document_status,
            created_at, updated_at
        ) VALUES (
            :user_id,
            :document_front_status, :document_back_status, :selfie_status, :contract_status, :document_status,
            :created_at, :updated_at
        )');

    $stmtDoc->execute([
        ':user_id'               => $newUserId,
        ':document_front_status' => 'not_sent',
        ':document_back_status'  => 'not_sent',
        ':selfie_status'         => 'not_sent',
        ':contract_status'       => 'not_sent',
        ':document_status'       => 'not_sent',
        ':created_at'            => $nowDoc,
        ':updated_at'            => $nowDoc,
    ]);

    // Gerar token de login para o novo usuário
    $token = generate_login_token($username);

    http_response_code(200);
    echo json_encode([
        'status' => 200,
        'data'   => null,
        'msg'    => $token,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao registrar usuário.'
    ]);
}
