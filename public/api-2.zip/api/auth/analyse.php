<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body) || !isset($body['document'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'JSON inválido. Informe document.'
    ]);
    exit;
}

$document = (string)$body['document'];

$payload = json_encode(['document' => $document], JSON_UNESCAPED_UNICODE);

$ch = curl_init();

curl_setopt_array($ch, [
    CURLOPT_URL            => 'https://client.pixupbr.com/api/auth/analyse',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => 5,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST  => 'POST',
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
    ],
]);

$response = curl_exec($ch);
$curlErr  = curl_error($ch);

curl_close($ch);

if ($curlErr) {
    http_response_code(502);
    echo json_encode([
        'status' => 502,
        'data'   => null,
        'msg'    => 'Erro ao chamar serviço de análise.'
    ]);
    exit;
}

// Espelhar o retorno da API externa
http_response_code(200);
echo $response;
