<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../helpers.php';

// Somente GET para este endpoint
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'msg'    => 'Método não permitido. Use GET.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();

[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired ' . ($token ?? 'null'),
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

$response = [
    'success'       => true,
    'notifications' => [],
];

http_response_code(200);
echo json_encode($response);