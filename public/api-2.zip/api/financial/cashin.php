<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

$token = get_auth_token_from_headers();

[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

// Buscar dados do usuário logado (email e documento)
try {
    $stmtUser = $pdo->prepare('SELECT email, document FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $userRow = $stmtUser->fetch();

    if (!$userRow) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'msg'    => 'Usuário não encontrado.',
        ]);
        exit;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'msg'    => 'Erro ao buscar dados do usuário.',
    ]);
    exit;
}

$userEmail    = $userRow['email'] ?? 'usergateway@example.com';
$userDocument = $userRow['document'] ?? '00000000000';

$userEmail    = $userRow['email'] ?? 'usergateway@example.com';
$userDocument = $userRow['document'] ?? '00000000000';

// Somente POST para este endpoint
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'msg'    => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();

[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired ' . ($token ?? 'null'),
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

// Lê o JSON enviado
$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body) || !isset($body['amount'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'msg'    => 'JSON inválido. Informe ao menos amount.',
    ]);
    exit;
}

$amount      = (float)$body['amount'];
$description = isset($body['description']) ? (string)$body['description'] : '';

if ($amount <= 0) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'msg'    => 'Valor inválido para amount.',
    ]);
    exit;
}

// Buscar credenciais da Podpay
try {
    $stmt = $pdo->query('SELECT private_key, public_key FROM podpay ORDER BY id ASC LIMIT 1');
    $podpay = $stmt->fetch();

    if (!$podpay) {
        http_response_code(500);
        echo json_encode([
            'status' => 500,
            'msg'    => 'Credenciais da Podpay não configuradas.',
        ]);
        exit;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'msg'    => 'Erro ao buscar credenciais da Podpay.',
    ]);
    exit;
}

$privateKey = $podpay['private_key'];
$publicKey  = $podpay['public_key'];

// Monta Authorization Basic private:public em base64
$authBasic = base64_encode($privateKey . ':' . $publicKey);

// Montar payload para Podpay
$payload = [
    'postbackUrl'   => 'https://polopay.online/internal/cashin/webhook.php',
    'amount'        => (int)round($amount * 100), // centavos
    'currency'      => 'BRL',
    'paymentMethod' => 'pix',
    'pix'           => [
        'expiresInDays' => 1,
    ],
    'items'         => [
        [
            'title'      => 'Deposito para Carteira - ' . $usernameFromToken,
            'unitPrice'  => (int)round($amount * 100),
            'quantity'   => 1,
            'tangible'   => false,
            'externalRef'=> '',
        ],
    ],
    'customer'      => [
        'name'  => $usernameFromToken,
        'email' => $userEmail,
        'document' => [
            'number' => $userDocument,
            'type'   => 'global',
        ],
    ],
];

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL            => 'https://api.podpay.co/v1/transactions',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING       => '',
    CURLOPT_MAXREDIRS      => 10,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST  => 'POST',
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_HTTPHEADER     => [
        'accept: application/json',
        'authorization: Basic ' . $authBasic,
        'content-type: application/json',
    ],
]);

$podpayResponse = curl_exec($curl);
$curlErr        = curl_error($curl);

curl_close($curl);

if ($curlErr) {
    http_response_code(502);
    echo json_encode([
        'status' => 502,
        'msg'    => 'Erro ao chamar Adquirente',
    ]);
    exit;
}

$podpayData = json_decode($podpayResponse, true);

if (!is_array($podpayData) || !isset($podpayData['id']) || !isset($podpayData['pix']['qrcode'])) {
    http_response_code(502);
    echo json_encode([
        'status' => 502,
        'msg'    => 'Resposta inesperada da Adquirente.',
        'raw'    => $podpayResponse,
    ]);
    exit;
}

$realTransactionId = $podpayData['id'];
$transactionId     = $podpayData['secureId'] ?? $podpayData['secureUrl'] ?? bin2hex(random_bytes(16));

// Buscar id do usuário
try {
    $stmtUserId = $pdo->prepare('SELECT id, balance_available FROM users WHERE username = :username LIMIT 1');
    $stmtUserId->execute([':username' => $usernameFromToken]);
    $userData = $stmtUserId->fetch();
} catch (PDOException $e) {
    $userData = false;
}

if ($userData) {
    $userId      = (int)$userData['id'];
    $oldBalance  = (float)$userData['balance_available'];
    $newBalance  = null; // ainda pendente
    $now         = date('Y-m-d H:i:s');

    try {
        $stmtIns = $pdo->prepare('INSERT INTO transactions (
            user_id, transaction_id, real_transaction_id, amount, fee, status, end_to_end_id,
            old_balance, new_balance, transaction_type, payment_method,
            description, created_at, updated_at
        ) VALUES (
            :user_id, :transaction_id, :real_transaction_id, :amount, :fee, :status, :end_to_end_id,
            :old_balance, :new_balance, :transaction_type, :payment_method,
            :description, :created_at, :updated_at
        )');

        $stmtIns->execute([
            ':user_id'             => $userId,
            ':transaction_id'      => $transactionId,
            ':real_transaction_id' => $realTransactionId,
            ':amount'              => $amount,
            ':fee'                 => 0.0,
            ':status'              => 0, // pendente
            ':end_to_end_id'       => null,
            ':old_balance'         => $oldBalance,
            ':new_balance'         => $newBalance,
            ':transaction_type'    => 1, // deposito
            ':payment_method'      => 0, // pix
            ':description'         => $description,
            ':created_at'          => $now,
            ':updated_at'          => $now,
        ]);
    } catch (PDOException $e) {
        // se falhar o insert, ainda assim retornamos o QRCode
    }
}

$response = [
    'external_id' => $transactionId,
    'qr_code'     => $podpayData['pix']['qrcode'],
];

http_response_code(200);
echo json_encode($response);
