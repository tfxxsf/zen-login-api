<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: text/plain; charset=utf-8');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo '405';
    exit;
}

// Autorização via token
$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo '401';
    exit;
}

// Pegar UUID da URL
// Ex: /api/financial/consult/{transactionId}
$uri = $_SERVER['REQUEST_URI'] ?? '';

// Remove query string
$uriPath = explode('?', $uri, 2)[0];
$parts   = explode('/', trim($uriPath, '/'));

// Esperado: ["api", "financial", "consult", "{uuid}"]
$transactionId = $parts[3] ?? null;

if (!$transactionId) {
    http_response_code(400);
    echo '400';
    exit;
}

try {
    // Buscar id do usuário para garantir que consulta só a própria transação
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $userRow = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$userRow) {
        http_response_code(404);
        echo '404';
        exit;
    }

    $userId = (int)$userRow['id'];

    $stmt = $pdo->prepare('SELECT status FROM transactions WHERE user_id = :user_id AND transaction_id = :transaction_id LIMIT 1');
    $stmt->execute([
        ':user_id'        => $userId,
        ':transaction_id' => $transactionId,
    ]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        // Não encontrou transação -> 0 (pendente) ou 404? Vou retornar 0 conforme pedido de status cru.
        http_response_code(200);
        echo '0';
        exit;
    }

    $status = (string)$row['status']; // 0,1,2

    http_response_code(200);
    echo $status;
} catch (Throwable $e) {
    http_response_code(500);
    echo '500';
}
