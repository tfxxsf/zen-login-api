<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente POST para este endpoint
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();

[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

// Lê o JSON enviado
$input = file_get_contents('php://input');
$body  = json_decode($input, true);

if (!is_array($body)
    || !isset($body['amount'])
    || !isset($body['pin'])
    || !isset($body['customer']['key'])
    || !isset($body['customer']['key_type'])
) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'JSON inválido. Verifique os campos enviados.'
    ]);
    exit;
}

$amount      = (float)$body['amount'];
$description = isset($body['description']) ? (string)$body['description'] : '';
$pin         = (string)$body['pin'];
$pixKey      = (string)$body['customer']['key'];
$keyTypeIn   = (string)$body['customer']['key_type'];

if ($amount <= 0) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'Valor inválido para saque.'
    ]);
    exit;
}

// Validar PIN: 6 dígitos
if (!preg_match('/^[0-9]{6}$/', $pin)) {
    http_response_code(400);
    echo json_encode([
        'status' => 400,
        'data'   => null,
        'msg'    => 'PIN inválido.'
    ]);
    exit;
}

try {
    // Buscar usuário com saldo e taxas
    $stmtUser = $pdo->prepare('SELECT id, balance_available, rate_cashout_fee, rate_min_fee
                               FROM users
                               WHERE username = :username
                               LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }

    $userId    = (int)$user['id'];
    $oldBalance = (float)$user['balance_available'];
    $rateFeePct = (float)$user['rate_cashout_fee'];   // porcentagem
    $rateMin    = (float)$user['rate_min_fee'];       // taxa fixa mínima

    // Validar PIN vinculado
    $stmtPin = $pdo->prepare('SELECT pin_code FROM pin_accounts WHERE user_id = :user_id LIMIT 1');
    $stmtPin->execute([':user_id' => $userId]);
    $pinRow = $stmtPin->fetch(PDO::FETCH_ASSOC);

    if (!$pinRow || $pinRow['pin_code'] !== $pin) {
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => null,
            'msg'    => 'PIN incorreto.'
        ]);
        exit;
    }

    // Calcular taxas: valor solicitado + rate_min_fee + % rate_cashout_fee
    $feePercent = $amount * $rateFeePct; // assumindo rate_cashout_fee já em fração (ex: 0.02)
    $totalFee   = $rateMin + $feePercent;
    $totalDebito = $amount + $totalFee;

    if ($oldBalance < $totalDebito) {
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => null,
            'msg'    => 'Saldo insuficiente para saque.'
        ]);
        exit;
    }

    // Converter key_type interno para formato Podpay
    $mapKeyType = [
        'TELEFONE'       => 'phone',
        'EMAIL'          => 'email',
        'CPF'            => 'cpf',
        'CNPJ'           => 'cnpj',
        'CHAVE_ALEATORIA'=> 'evp',
        'EVP'            => 'copypaste',
    ];

    $podpayKeyType = $mapKeyType[$keyTypeIn] ?? null;

    if (!$podpayKeyType) {
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => null,
            'msg'    => 'Tipo de chave inválido.'
        ]);
        exit;
    }

    // Buscar credenciais Podpay (inclui withdraw_key)
    $stmtPod = $pdo->query('SELECT private_key, public_key, withdraw_key FROM podpay ORDER BY id ASC LIMIT 1');
    $podpay  = $stmtPod->fetch(PDO::FETCH_ASSOC);

    if (!$podpay) {
        http_response_code(500);
        echo json_encode([
            'status' => 500,
            'data'   => null,
            'msg'    => 'Credenciais da Podpay não configuradas.'
        ]);
        exit;
    }

    $privateKey   = $podpay['private_key'];
    $publicKey    = $podpay['public_key'];
    $withdrawKey  = $podpay['withdraw_key'];
    $authBasic    = base64_encode($privateKey . ':' . $publicKey);

    // Montar payload para Podpay transfers
    $payload = [
        'method'    => 'fiat',
        'amount'    => (int)round($amount * 100), // valor em centavos
        'netPayout' => true,
        'pixKey'    => $pixKey,
        'pixKeyType'=> $podpayKeyType,
    ];

    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL            => 'https://api.podpay.co/v1/transfers',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING       => '',
        CURLOPT_MAXREDIRS      => 10,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST  => 'POST',
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'accept: application/json',
            'authorization: Basic ' . $authBasic,
            'content-type: application/json',
            'x-withdraw-key: ' . $withdrawKey,
        ],
    ]);

    $podpayResponse = curl_exec($curl);
    $curlErr        = curl_error($curl);

    curl_close($curl);

    if ($curlErr) {
        http_response_code(502);
        echo json_encode([
            'status' => 502,
            'data'   => null,
            'msg'    => 'Erro ao chamar Adquirente para saque.'
        ]);
        exit;
    }

    $podpayData = json_decode($podpayResponse, true);

    if (!is_array($podpayData) || isset($podpayData['code'])) {
        // Erro 400 ou resposta inesperada
        http_response_code(400);
        echo json_encode([
            'status' => 400,
            'data'   => $podpayData,
            'msg'    => $podpayData['message'] ?? 'Erro ao processar saque.'
        ]);
        exit;
    }

    // Espera-se um objeto com id, status, etc.
    $transferId   = $podpayData['id'] ?? null;
    $status       = $podpayData['status'] ?? null;
    $descriptionP = $podpayData['description'] ?? '';

    if (!$transferId) {
        http_response_code(502);
        echo json_encode([
            'status' => 502,
            'data'   => $podpayData,
            'msg'    => 'Resposta inesperada da Adquirente.'
        ]);
        exit;
    }

    // Mapear status Podpay para nosso status interno
    // 0 = pendente, 1 = pago, 2 = estornado/cancelado
    $internalStatus = 1;
    if ($status === 'COMPLETED') {
        $internalStatus = 1;
    } elseif (in_array($status, ['CANCELLED', 'REFUSED'], true)) {
        $internalStatus = 2;
    }

    $now = date('Y-m-d H:i:s');

    // Inserir transação de cashout (transaction_type = 2)
    $stmtIns = $pdo->prepare('INSERT INTO transactions (
            user_id, transaction_id, real_transaction_id, amount, fee, status, end_to_end_id,
            old_balance, new_balance, transaction_type, payment_method,
            description, created_at, updated_at
        ) VALUES (
            :user_id, :transaction_id, :real_transaction_id, :amount, :fee, :status, :end_to_end_id,
            :old_balance, :new_balance, :transaction_type, :payment_method,
            :description, :created_at, :updated_at
        )');

    // new_balance será calculado após débito
    $newBalance = $oldBalance - $totalDebito;

    $stmtIns->execute([
        ':user_id'             => $userId,
        ':transaction_id'      => $transferId,
        ':real_transaction_id' => $transferId,
        ':amount'              => $amount,
        ':fee'                 => $totalFee,
        ':status'              => $internalStatus,
        ':end_to_end_id'       => $podpayData['pixEnd2EndId'] ?? null,
        ':old_balance'         => $oldBalance,
        ':new_balance'         => $newBalance,
        ':transaction_type'    => 2, // saque
        ':payment_method'      => 0, // pix
        ':description'         => $description,
        ':created_at'          => $now,
        ':updated_at'          => $now,
    ]);

    // Atualizar saldo do usuário com débito total (valor + taxas)
    $stmtUpdBalance = $pdo->prepare('UPDATE users
                                     SET balance_available = :new_balance
                                     WHERE id = :id');
    $stmtUpdBalance->execute([
        ':new_balance' => $newBalance,
        ':id'          => $userId,
    ]);

    http_response_code(200);
    echo json_encode([
        'status' => 200,
        'data'   => $podpayData,
        'msg'    => 'Solicitação de saque enviada com sucesso.',
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao processar saque.'
    ]);
}
