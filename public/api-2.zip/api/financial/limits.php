<?php

echo '
[
    {
        "key": "daily_limit",
        "title": "Limite Di\u00e1rio",
        "goal": "100000.000000",
        "currency": true
    },
    {
        "key": "per_withdraw",
        "title": "Limite por Saque",
        "goal": 10000,
        "currency": true
    },
    {
        "key": "withdraw_per_cpf",
        "title": "Limite por CPF",
        "goal": "5000.000000",
        "currency": true
    },
    {
        "key": "qt_withdraws_per_cpf",
        "title": "Saques por CPF Diario",
        "goal": "50.000",
        "currency": false
    }
]
';