<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../helpers.php';

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'msg'     => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'msg'     => 'Token inválido ou expirado.'
    ]);
    exit;
}

// Aceita upload via multipart/form-data (campo "file") OU base64 no body (raw ou JSON)
$imageData = '';

if (
    isset($_FILES['file']) &&
    $_FILES['file']['error'] === UPLOAD_ERR_OK &&
    is_uploaded_file($_FILES['file']['tmp_name'])
) {
    $imageData = (string) file_get_contents($_FILES['file']['tmp_name']);
} else {
    $input = (string) file_get_contents('php://input');
    $input = trim($input);

    if ($input !== '' && ($input[0] === '{' || $input[0] === '[')) {
        $json = json_decode($input, true);
        if (is_array($json)) {
            $maybeBase64 = '';
            if (isset($json['file'])) {
                $maybeBase64 = (string) $json['file'];
            } elseif (isset($json['base64'])) {
                $maybeBase64 = (string) $json['base64'];
            } elseif (isset($json['image'])) {
                $maybeBase64 = (string) $json['image'];
            }
            $input = trim($maybeBase64);
        }
    }

    if ($input !== '' && str_contains($input, 'base64,')) {
        $input = trim((string) substr($input, strpos($input, 'base64,') + 7));
    }

    if ($input !== '') {
        $decoded = base64_decode($input, true);
        if ($decoded !== false) {
            $imageData = $decoded;
        }
    }
}

if ($imageData === '' || strlen($imageData) < 32) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'msg'     => 'Imagem inválida ou vazia.'
    ]);
    exit;
}

try {
    // Buscar usuário
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'msg'     => 'Usuário não encontrado.'
        ]);
        exit;
    }

    $userId = (int)$user['id'];

    // Salvar arquivo em disco
    $dir = __DIR__ . '/../../storage/documents/' . $userId;
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    $filename = $dir . '/document_front_' . date('Ymd_His') . '.jpg';
    file_put_contents($filename, $imageData);

    if (!is_file($filename) || filesize($filename) <= 0) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'msg'     => 'Falha ao salvar a imagem.'
        ]);
        exit;
    }

    $publicUrl = '/storage/documents/' . $userId . '/' . basename($filename);

    $now = (new DateTime())->format('Y-m-d H:i:s');

    // Atualizar tabela documents com URL e status pending
    $stmtDoc = $pdo->prepare('UPDATE documents
                              SET document_front_url = :url,
                                  document_front_status = :status,
                                  document_status = :document_status,
                                  updated_at = :updated_at
                              WHERE user_id = :user_id');
    $stmtDoc->execute([
        ':url'             => $publicUrl,
        ':status'          => 'pending',
        ':document_status' => 'pending',
        ':updated_at'      => $now,
        ':user_id'         => $userId,
    ]);

    // Atualizar status na tabela users para frente do documento
    $stmtUserDoc = $pdo->prepare('UPDATE users
                                  SET document_front_status = :status,
                                      document_status = :document_status
                                  WHERE id = :id');
    $stmtUserDoc->execute([
        ':status'          => 'pending',
        ':document_status' => 'pending',
        ':id'              => $userId,
    ]);

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'msg'     => 'Frente do Documento enviado com sucesso! Aguarde aprovação.'
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'msg'     => 'Erro ao enviar documento.'
    ]);
}
