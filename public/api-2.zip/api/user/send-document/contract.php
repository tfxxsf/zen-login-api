<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../helpers.php';

// Somente POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'msg'     => 'Método não permitido. Use POST.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'msg'     => 'Token inválido ou expirado.'
    ]);
    exit;
}

// Upload via multipart/form-data: campo "file"
if (
    !isset($_FILES['file']) ||
    $_FILES['file']['error'] !== UPLOAD_ERR_OK ||
    !is_uploaded_file($_FILES['file']['tmp_name'])
) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'msg'     => 'Arquivo inválido.'
    ]);
    exit;
}

$binaryData = file_get_contents($_FILES['file']['tmp_name']);

if ($binaryData === false || $binaryData === '') {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'msg'     => 'Arquivo inválido.'
    ]);
    exit;
}

try {
    $stmtUser = $pdo->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'msg'     => 'Usuário não encontrado.'
        ]);
        exit;
    }

    $userId = (int)$user['id'];

    $dir = __DIR__ . '/../../storage/documents/' . $userId;
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    $filename = $dir . '/contract_' . date('Ymd_His') . '.pdf';
    file_put_contents($filename, $binaryData);

    $publicUrl = '/storage/documents/' . $userId . '/' . basename($filename);

    $now = (new DateTime())->format('Y-m-d H:i:s');

    $stmtDoc = $pdo->prepare('UPDATE documents
                              SET contract_url = :url,
                                  contract_status = :status,
                                  document_status = :document_status,
                                  updated_at = :updated_at
                              WHERE user_id = :user_id');
    $stmtDoc->execute([
        ':url'             => $publicUrl,
        ':status'          => 'pending',
        ':document_status' => 'pending',
        ':updated_at'      => $now,
        ':user_id'         => $userId,
    ]);

    // Atualizar status na tabela users para contrato
    $stmtUserDoc = $pdo->prepare('UPDATE users
                                  SET contract_status = :status,
                                      document_status = :document_status
                                  WHERE id = :id');
    $stmtUserDoc->execute([
        ':status'          => 'pending',
        ':document_status' => 'pending',
        ':id'              => $userId,
    ]);

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'msg'     => 'Contrato Social enviado com sucesso! Aguarde aprovação.'
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'msg'     => 'Erro ao enviar documento.'
    ]);
}
