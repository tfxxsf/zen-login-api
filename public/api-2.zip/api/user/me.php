<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Max-Age: 86400');

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Somente GET para este endpoint
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'msg'    => 'Método não permitido. Use GET.'
    ]);
    exit;
}

// Captura o token do header Authorization usando o helper
$token = get_auth_token_from_headers();

[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare('SELECT
        username,
        name,
        email,
        phone,
        profile,
        document,
        document_status,
        status,
        manager_name,
        manager_phone,
        created_at,
        document_front_status,
        document_back_status,
        selfie_status,
        contract_status
      FROM users
      WHERE username = :username
      LIMIT 1');

    $stmt->execute([':username' => $usernameFromToken]);
    $row = $stmt->fetch();

    if (!$row) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao buscar dados do usuário.'
    ]);
    exit;
}

$response = [
    'name'             => $row['name'],
    'username'         => $row['username'],
    'email'            => $row['email'],
    'phone'            => $row['phone'],
    'profile'          => $row['profile'],
    'document'         => $row['document'],
    'document_status'  => $row['document_status'],
    'status'           => (int)$row['status'],
    'manager'          => [
        'name'  => $row['manager_name'],
        'phone' => $row['manager_phone'],
    ],
    'created_at'       => $row['created_at'],
    'document_details' => [
        'document_front' => $row['document_front_status'],
        'document_back'  => $row['document_back_status'],
        'selfie'         => $row['selfie_status'],
        'contract'       => $row['contract_status'],
    ],
];

http_response_code(200);
echo json_encode($response);
