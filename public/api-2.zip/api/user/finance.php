<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente GET para este endpoint
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'msg'    => 'Método não permitido. Use GET.'
    ]);
    exit;
}

// Captura o token do header Authorization usando o helper
$token = get_auth_token_from_headers();

[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare('SELECT
        id,
        balance_available,
        balance_blocked,
        balance_retained,
        revenue_total,
        revenue_monthly_revenue,
        revenue_ranking,
        revenue_next_meta,
        rate_cashin_fee,
        rate_cashin_type,
        rate_cashout_fee,
        rate_cashout_type,
        rate_cashout_api_fee,
        rate_cashout_api_type,
        rate_cripto_fee,
        rate_min_fee
      FROM users
      WHERE username = :username
      LIMIT 1');

    $stmt->execute([':username' => $usernameFromToken]);
    $row = $stmt->fetch();

    if (!$row) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao buscar dados financeiros.'
    ]);
    exit;
}

// Calcula métricas a partir das transactions (apenas pagamentos concluídos)
$ticketAvg         = 0.0;
$dailyAvg          = 0.0;
$countTransactions = 0;
// Total recebido hoje (somente entradas aprovadas)
$receivedToday     = 0.0;

try {
    $userId = (int)$row['id'];

    // Ticket médio e quantidade de transações aprovadas (apenas entradas - transaction_type = 1)
    $stmtTicket = $pdo->prepare('SELECT
        COALESCE(SUM(amount), 0) AS total_amount,
        COUNT(*) AS total_count
      FROM transactions
      WHERE user_id = :user_id
        AND status = 1
        AND transaction_type = 1');

    $stmtTicket->execute([':user_id' => $userId]);
    $t = $stmtTicket->fetch();

    if ($t && (int)$t['total_count'] > 0) {
        $countTransactions = (int)$t['total_count'];
        $ticketAvg         = (float)$t['total_amount'] / $countTransactions;
    }

    // Média diária: soma(amount) / número de dias distintos com transações (apenas entradas - transaction_type = 1)
    $stmtDaily = $pdo->prepare('SELECT
        COALESCE(SUM(amount), 0) AS total_amount,
        COUNT(DISTINCT DATE(created_at)) AS total_days
      FROM transactions
      WHERE user_id = :user_id
        AND status = 1
        AND transaction_type = 1');

    $stmtDaily->execute([':user_id' => $userId]);
    $d = $stmtDaily->fetch();

    if ($d && (int)$d['total_days'] > 0) {
        $dailyAvg = (float)$d['total_amount'] / (int)$d['total_days'];
    }

    // Total recebido hoje (entradas aprovadas, transaction_type = 1, data de hoje)
    $todayStart = date('Y-m-d 00:00:00');
    $todayEnd   = date('Y-m-d 23:59:59');

    $stmtToday = $pdo->prepare('SELECT
            COALESCE(SUM(amount), 0) AS total_amount
        FROM transactions
        WHERE user_id = :user_id
          AND status = 1
          AND transaction_type = 1
          AND created_at BETWEEN :start AND :end');

    $stmtToday->execute([
        ':user_id' => $userId,
        ':start'   => $todayStart,
        ':end'     => $todayEnd,
    ]);

    $tToday = $stmtToday->fetch(PDO::FETCH_ASSOC);
    if ($tToday && isset($tToday['total_amount'])) {
        $receivedToday = (float)$tToday['total_amount'];
    }

} catch (PDOException $e) {
    // mantém valores 0.0
}

// Receita total: soma das transações de entrada aprovadas (transaction_type = 1)
$revenueTotalDynamic = 0.0;

try {
    $stmtMonthly = $pdo->prepare('SELECT
            COALESCE(SUM(amount), 0) AS total_amount
        FROM transactions
        WHERE user_id = :user_id
          AND status = 1
          AND transaction_type = 1');

    $stmtMonthly->execute([
        ':user_id' => $userId,
    ]);

    $m = $stmtMonthly->fetch(PDO::FETCH_ASSOC);
    if ($m && isset($m['total_amount'])) {
        $revenueTotalDynamic = (float)$m['total_amount'];
    }
} catch (PDOException $e) {
    // mantém 0.0 se der erro
}

$response = [
    'balance_available' => (string)$row['balance_available'],
    'balance_blocked'   => (string)$row['balance_blocked'],
    'balance_retained'  => (string)$row['balance_retained'],
    'received_total'    => $receivedToday,
    'revenue'           => [
        'total'              => $revenueTotalDynamic,
        'ticket_avg'         => $ticketAvg,
        'daily_avg'          => $dailyAvg,
        'count_transactions' => $countTransactions,
        'monthly_revenue'    => (float)$row['revenue_monthly_revenue'],
        'ranking'            => $row['revenue_ranking'],
        'next_meta'          => (int)$row['revenue_next_meta'],
    ],
    'rates'             => [
        'cashin_fee'      => (float)$row['rate_cashin_fee'],
        'cashin_type'     => (int)$row['rate_cashin_type'],
        'cashout_fee'     => (float)$row['rate_cashout_fee'],
        'cashout_type'    => (int)$row['rate_cashout_type'],
        'cashout_api_fee' => (float)$row['rate_cashout_api_fee'],
        'cashout_api_type'=> (int)$row['rate_cashout_api_type'],
        'cripto_fee'      => (float)$row['rate_cripto_fee'],
        'min_fee'         => (float)$row['rate_min_fee'],
    ],
];

http_response_code(200);
echo json_encode($response);
