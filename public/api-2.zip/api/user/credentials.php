<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Somente GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'status' => 405,
        'data'   => null,
        'msg'    => 'Método não permitido. Use GET.'
    ]);
    exit;
}

$token = get_auth_token_from_headers();
[$validToken, $usernameFromToken] = $token
    ? validate_login_token($token)
    : [false, null];

if (!$validToken || !$usernameFromToken) {
    http_response_code(401);
    echo json_encode([
        'status' => 401,
        'data'   => 'token_expired',
        'msg'    => 'Token inválido ou expirado.'
    ]);
    exit;
}

try {
    // Buscar usuário (inclui document_status para decidir active)
    $stmtUser = $pdo->prepare('SELECT id, name, document_status FROM users WHERE username = :username LIMIT 1');
    $stmtUser->execute([':username' => $usernameFromToken]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode([
            'status' => 404,
            'data'   => null,
            'msg'    => 'Usuário não encontrado.'
        ]);
        exit;
    }

    $userId   = (int)$user['id'];
    $userName = $user['name'] ?? $usernameFromToken;
    $isApproved = isset($user['document_status']) && $user['document_status'] === 'approved';

    // Verificar se já existe credencial para este usuário
    $stmtCred = $pdo->prepare('SELECT id, client_id, secret_id, name, description, created_at, active
                               FROM credentials
                               WHERE user_id = :user_id
                               LIMIT 1');
    $stmtCred->execute([':user_id' => $userId]);
    $credential = $stmtCred->fetch(PDO::FETCH_ASSOC);

    if (!$credential) {
        // Gerar nova credencial
        $randomNumeric = substr(strval(mt_rand(1000000000000000, 9999999999999999)), 0, 16);
        $clientId      = $usernameFromToken . '_' . $randomNumeric;

        // Secret de 16 caracteres: 8 letras minúsculas e 8 números, misturados
        $letters = 'abcdefghijklmnopqrstuvwxyz';
        $digits  = '0123456789';

        $secretChars = [];

        // 8 letras
        for ($i = 0; $i < 16; $i++) {
            $secretChars[] = $letters[random_int(0, strlen($letters) - 1)];
        }

        // 8 números
        for ($i = 0; $i < 16; $i++) {
            $secretChars[] = $digits[random_int(0, strlen($digits) - 1)];
        }

        // embaralhar tudo para não ficar metades separadas
        shuffle($secretChars);

        $secret = implode('', $secretChars);

        $now = (new DateTime())->format('Y-m-d H:i:s');

        $stmtInsert = $pdo->prepare('INSERT INTO credentials
            (user_id, client_id, secret_id, name, description, active, created_at)
            VALUES
            (:user_id, :client_id, :secret_id, :name, :description, :active, :created_at)');

        $stmtInsert->execute([
            ':user_id'     => $userId,
            ':client_id'   => $clientId,
            ':secret_id'   => $secret,
            ':name'        => $userName,
            ':description' => '',
            ':active'      => 1,
            ':created_at'  => $now,
        ]);

        $credential = [
            'id'          => $pdo->lastInsertId(),
            'client_id'   => $clientId,
            'secret_id'   => $secret,
            'name'        => $userName,
            'description' => '',
            'active'      => 1,
            'created_at'  => $now,
        ];
    }

    // Buscar allowed_ips do usuário
    $stmtIps = $pdo->prepare('SELECT ip FROM allowed_ips WHERE user_id = :user_id');
    $stmtIps->execute([':user_id' => $userId]);
    $ips = [];
    while ($row = $stmtIps->fetch(PDO::FETCH_ASSOC)) {
        $ips[] = $row['ip'];
    }

    // Garantir defaults para evitar null
    $clientIdOut   = $credential['client_id'] ?? null;
    $descriptionOut = $credential['description'] ?? '';
    $createdAtOut   = $credential['created_at'] ?? null;

    // active baseado no document_status do usuário
    $activeOut = $isApproved ? 1 : 0;

    $response = [
        'name'        => $credential['name'] ?? $userName,
        'client_id'   => $clientIdOut,
        'description' => $descriptionOut,
        'allowed_ips' => $ips,
        'created_at'  => $createdAtOut,
        'active'      => $activeOut,
    ];

    http_response_code(200);
    echo json_encode($response);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 500,
        'data'   => null,
        'msg'    => 'Erro ao carregar credenciais.'
    ]);
}
