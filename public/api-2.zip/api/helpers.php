<?php

// Timezone padrão da aplicação

// Idealmente, mova esta chave para uma variável de ambiente.
const AUTH_SECRET_KEY = 'mude_esta_chave_para_uma_bem_grande_e_secreta_32chars+';
const AUTH_CIPHER     = 'AES-256-CBC';

/**
 * Gera um token de login com validade de 1 hora.
 * Payload em texto claro (antes da criptografia):
 * {
 *   "username": "...",
 *   "exp": 1234567890
 * }
 *
 * Token final: base64(iv + ciphertext)
 */
function generate_login_token(string $username): string
{
    $expiresAt = time() + 3600; // 1 hora

    $payload = json_encode([
        'username' => $username,
        'exp'      => $expiresAt,
    ], JSON_UNESCAPED_UNICODE);

    $ivLength = openssl_cipher_iv_length(AUTH_CIPHER);
    $iv       = random_bytes($ivLength);

    $ciphertext = openssl_encrypt(
        $payload,
        AUTH_CIPHER,
        AUTH_SECRET_KEY,
        OPENSSL_RAW_DATA,
        $iv
    );

    if ($ciphertext === false) {
        // Em caso de falha improvável, ainda assim não expor detalhes
        throw new RuntimeException('Falha ao gerar token.');
    }

    // token = base64(iv + ciphertext)
    return base64_encode($iv . $ciphertext);
}

/**
 * Captura o token do header Authorization (ou variações) no formato Bearer <token>.
 * Retorna null se não encontrar.
 */
function get_auth_token_from_headers(): ?string
{
    $authHeader = '';

    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
    } elseif (isset($_SERVER['AUTHORIZATION'])) {
        $authHeader = $_SERVER['AUTHORIZATION'];
    } elseif (function_exists('getallheaders')) {
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            $authHeader = $headers['Authorization'];
        } elseif (isset($headers['authorization'])) {
            $authHeader = $headers['authorization'];
        }
    }

    if (!$authHeader || stripos($authHeader, 'Bearer ') !== 0) {
        return null;
    }

    $token = trim(substr($authHeader, 7));

    return $token !== '' ? $token : null;
}

/**
 * Verifica se o token é válido e não expirou.
 * Retorna um array [bool $valid, ?string $username].
 */
function validate_login_token(string $token): array
{
    $raw = base64_decode($token, true);
    if ($raw === false) {
        return [false, null];
    }

    $ivLength = openssl_cipher_iv_length(AUTH_CIPHER);
    if (strlen($raw) <= $ivLength) {
        return [false, null];
    }

    $iv         = substr($raw, 0, $ivLength);
    $ciphertext = substr($raw, $ivLength);

    $payloadJson = openssl_decrypt(
        $ciphertext,
        AUTH_CIPHER,
        AUTH_SECRET_KEY,
        OPENSSL_RAW_DATA,
        $iv
    );

    if ($payloadJson === false) {
        return [false, null];
    }

    $payload = json_decode($payloadJson, true);
    if (!is_array($payload) || empty($payload['username']) || empty($payload['exp'])) {
        return [false, null];
    }

    if ((int)$payload['exp'] < time()) {
        return [false, null];
    }

    return [true, $payload['username']];
}
